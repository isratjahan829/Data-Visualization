Overleaf project: "Can AI Substitute for Classroom Teachers in Higher Education?"
1. Overleaf -> New Project -> Upload Project -> choose this zip.
2. Menu -> Compiler: pdfLaTeX, Main document: main.tex. Click Recompile.
Files: main.tex (manuscript), refs.bib (references), generated/ (numbers & tables
auto-generated from the analysis code - do not edit by hand), figures/ (vector PDFs).
Before submission fill in: [University name], [City], [Country], the generative-AI
declaration and the funding statement.
